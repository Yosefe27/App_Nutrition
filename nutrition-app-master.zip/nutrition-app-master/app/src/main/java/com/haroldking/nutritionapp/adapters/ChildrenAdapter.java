package com.haroldking.nutritionapp.adapters;
/*
 * Created by Harold King on 6/03/2019.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.haroldking.nutritionapp.R;
import com.haroldking.nutritionapp.model.Children;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class ChildrenAdapter extends RecyclerView.Adapter<ChildrenAdapter.SingleViewHolder> {

    public static List<Children> listChildren;
    private Children currentChildren;
    private Context mContext;
    private List<Children> listFullChildren;
    View.OnClickListener clickListener;
    // if checkedPosition = -1, there is no default selection
    // if checkedPosition = 0, 1st item is selected by default
    private int checkedPosition = -1;

    //constructor
    public ChildrenAdapter(Context context, ArrayList<Children> listChildren) {
        this.mContext = context;
        this.listChildren = listChildren;
        listFullChildren = new ArrayList<>(listChildren);

    }

    public void setClickListener(View.OnClickListener callback) {
        clickListener = callback;
    }
    public void setChildren(List<Children> listChildren) {
        this.listChildren = listChildren;
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return listChildren.size();
    }

    public class SingleViewHolder extends RecyclerView.ViewHolder {

        public TextView item_name ;
        private CircleImageView item_image;


        public SingleViewHolder(View itemView) {
            super(itemView);

            item_name = itemView.findViewById(R.id.item_name);
            item_image = itemView.findViewById(R.id.item_image);

        }//ends public viewholder

       /* void bind(final Children transactions) {
            initials.setText(transactions.getInitials());
            fullname.setText(transactions.getFullname());
            transaction_type_date.setText(transactions.getTransaction_type());
            amount.setText(transactions.getTransaction_amount());
//
//
        }*/
    }

    @Override
    public SingleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //inflating the layouts of each row
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.list_item_stuff, parent, false);
        return new SingleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SingleViewHolder holder, int position) {
        currentChildren = listChildren.get(position);
        //holder.bind(listChildren.get(position));




        holder.item_name.setText(String.valueOf(currentChildren.getOthernames()+" "+currentChildren.getSurname()));
        //PicassoClient.loadPosImage(mContext, BASE_URL + "pos/images/"+currentChildren.getImage_url()+".jpg", holder.company_image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickListener.onClick(view);

            }
        });
    }



}
