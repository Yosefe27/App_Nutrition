package com.haroldking.nutritionapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.haroldking.nutritionapp.databases.DatabaseHelper;
import com.haroldking.nutritionapp.model.Children;
import com.haroldking.nutritionapp.model.Mother;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    FrameLayout frame_num_of_mothers, frame_num_of_children;
    TextView number_of_mothers, number_of_children;
    DatabaseHelper databaseHelper;
    Context context;
    ArrayList<Mother> listMothers = new ArrayList<>();
    ArrayList<Children> listChildren = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frame_num_of_children = findViewById(R.id.frame_num_of_children);
        frame_num_of_mothers = findViewById(R.id.frame_num_of_mothers);
        number_of_children = findViewById(R.id.num_of_children);
        number_of_mothers = findViewById(R.id.num_of_mothers);
        context = MainActivity.this;
        databaseHelper = new DatabaseHelper(context);
        listMothers = databaseHelper.getMothersBasedOnUserLoggedIn("1");
        listChildren = databaseHelper.getChildrenBasedOnMother("1");
        number_of_mothers.setText(String.valueOf(listMothers.size()));
        number_of_children.setText(String.valueOf(listChildren.size()));
        frame_num_of_mothers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent intent = new Intent(getApplicationContext(), MothersActivity.class);
                startActivity(intent);
            }
        });

    }
}