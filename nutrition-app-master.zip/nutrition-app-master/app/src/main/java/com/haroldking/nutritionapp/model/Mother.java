package com.haroldking.nutritionapp.model;

public class Mother {

    private int mother_id;
    private String othernames;
    private String surname;
    private String dob;
    private String current_age;
    private String nrc;
    private String gender;
    private int num_of_children;
    private String phone_number;
    private String date_created;


    public Mother() {

    }

    public Mother(int mother_id, String othernames, String surname, String dob, String current_age, String nrc, String gender, int num_of_children, String phone_number, String date_created) {
        this.mother_id = mother_id;
        this.othernames = othernames;
        this.surname = surname;
        this.dob = dob;
        this.current_age = current_age;
        this.nrc = nrc;
        this.gender = gender;
        this.num_of_children = num_of_children;
        this.phone_number = phone_number;
        this.date_created = date_created;
    }

    public int getMother_id() {
        return mother_id;
    }

    public void setMother_id(int mother_id) {
        this.mother_id = mother_id;
    }

    public String getOthernames() {
        return othernames;
    }

    public void setOthernames(String othernames) {
        this.othernames = othernames;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getCurrent_age() {
        return current_age;
    }

    public void setCurrent_age(String current_age) {
        this.current_age = current_age;
    }

    public String getNrc() {
        return nrc;
    }

    public void setNrc(String nrc) {
        this.nrc = nrc;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getNum_of_children() {
        return num_of_children;
    }

    public void setNum_of_children(int num_of_children) {
        this.num_of_children = num_of_children;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }
}
