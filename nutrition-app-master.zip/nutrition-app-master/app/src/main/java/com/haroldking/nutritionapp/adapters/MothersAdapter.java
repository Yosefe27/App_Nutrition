package com.haroldking.nutritionapp.adapters;
/*
 * Created by Harold King on 6/03/2019.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.haroldking.nutritionapp.R;
import com.haroldking.nutritionapp.model.Mother;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class MothersAdapter extends RecyclerView.Adapter<MothersAdapter.SingleViewHolder> {

    public static List<Mother> listMother;
    private Mother currentMother;
    private Context mContext;
    private List<Mother> listFullMother;
    View.OnClickListener clickListener;
    // if checkedPosition = -1, there is no default selection
    // if checkedPosition = 0, 1st item is selected by default
    private int checkedPosition = -1;

    //constructor
    public MothersAdapter(Context context, ArrayList<Mother> listMother) {
        this.mContext = context;
        this.listMother = listMother;
        listFullMother = new ArrayList<>(listMother);

    }

    public void setClickListener(View.OnClickListener callback) {
        clickListener = callback;
    }
    public void setMother(List<Mother> listMother) {
        this.listMother = listMother;
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return listMother.size();
    }

    public class SingleViewHolder extends RecyclerView.ViewHolder {

        public TextView item_name ;
        private CircleImageView item_image;


        public SingleViewHolder(View itemView) {
            super(itemView);

            item_name = itemView.findViewById(R.id.item_name);
            item_image = itemView.findViewById(R.id.item_image);

        }//ends public viewholder

       /* void bind(final Mother transactions) {
            initials.setText(transactions.getInitials());
            fullname.setText(transactions.getFullname());
            transaction_type_date.setText(transactions.getTransaction_type());
            amount.setText(transactions.getTransaction_amount());
//
//
        }*/
    }

    @Override
    public SingleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //inflating the layouts of each row
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.list_item_stuff, parent, false);
        return new SingleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SingleViewHolder holder, int position) {
        currentMother = listMother.get(position);
        //holder.bind(listMother.get(position));




        holder.item_name.setText(String.valueOf(currentMother.getOthernames()+" "+currentMother.getSurname()));
        //PicassoClient.loadPosImage(mContext, BASE_URL + "pos/images/"+currentMother.getImage_url()+".jpg", holder.company_image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickListener.onClick(view);

            }
        });
    }



}
