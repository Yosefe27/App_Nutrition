package com.haroldking.nutritionapp.model;

public class Children {

    private int mother_id;
    private String othernames;
    private String surname;
    private String dob;
    private String current_age;
    private String gender;
    private String date_created;

    public Children() {

    }

    public Children(int mother_id, String othernames, String surname, String dob, String current_age, String gender, String date_created) {
        this.mother_id = mother_id;
        this.othernames = othernames;
        this.surname = surname;
        this.dob = dob;
        this.current_age = current_age;
        this.gender = gender;
        this.date_created = date_created;
    }

    public int getMother_id() {
        return mother_id;
    }

    public void setMother_id(int mother_id) {
        this.mother_id = mother_id;
    }

    public String getOthernames() {
        return othernames;
    }

    public void setOthernames(String othernames) {
        this.othernames = othernames;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getCurrent_age() {
        return current_age;
    }

    public void setCurrent_age(String current_age) {
        this.current_age = current_age;
    }


    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }
}
