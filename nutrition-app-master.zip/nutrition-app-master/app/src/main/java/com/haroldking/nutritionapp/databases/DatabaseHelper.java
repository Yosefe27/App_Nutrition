package com.haroldking.nutritionapp.databases;

/**
 * Created by Harold King on 6/05/2020.
 */


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.haroldking.nutritionapp.model.Children;
import com.haroldking.nutritionapp.model.Mother;

import java.util.ArrayList;


public class DatabaseHelper extends SQLiteOpenHelper {

    //STRING KEYS FOR TABLE NAMES
    private static final String KEY_LID = "id";
    public static final String TABLE_MOTHERS = "tbl_mothers";
    public static final String TABLE_CHILDREN = "tbl_children";


    public static final String KEY_OTHERNAMES = "othernames";
    public static final String KEY_SURNAME = "surname";
    public static final String KEY_DOB = "dob";
    public static final String KEY_CURRENT_AGE = "current_age";
    public static final String KEY_NRC = "nrc";
    public static final String KEY_GENDER = "gender";
    public static final String KEY_PHONE_NUMBER = "phone_number";
    public static final String KEY_DATE_CREATED = "date_created";
    public static final String KEY_DATE_MODIFIED = "date_modified";
    public static final String KEY_SUBMITTED_BY = "submitted_by";

    public static final String KEY_MOTHER_ID = "mother_id";


    //STRING KEYS FOR DATABASE DETAILS
    public static final int DATABASE_VERSION = 1;
    public static String DATABASE_NAME = "nutrition_app";

    // private ArrayList<Users> listUsers;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    DatabaseHelper dbHelper;

    @Override
    public void onCreate(SQLiteDatabase db) {


        String CREATE_MOTHERS_TABLE = "CREATE TABLE " + TABLE_MOTHERS + "("
                + KEY_LID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_OTHERNAMES + " TEXT,"
                + KEY_SURNAME + " TEXT,"
                + KEY_DOB + " TEXT,"
                + KEY_CURRENT_AGE + " TEXT, "
                + KEY_NRC + " TEXT, "
                + KEY_GENDER + " TEXT,"
                + KEY_PHONE_NUMBER + " TEXT,"
                + KEY_SUBMITTED_BY + " TEXT,"
                + KEY_DATE_CREATED + " TEXT,"
                + KEY_DATE_MODIFIED + " TEXT " + ")";
        db.execSQL(CREATE_MOTHERS_TABLE);

        String CREATE_CHILDREN_TABLE = "CREATE TABLE " + TABLE_CHILDREN + "("
                + KEY_LID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_MOTHER_ID + " INTEGER,"
                + KEY_OTHERNAMES + " TEXT,"
                + KEY_SURNAME + " TEXT,"
                + KEY_DOB + " TEXT,"
                + KEY_CURRENT_AGE + " TEXT, "
                + KEY_GENDER + " TEXT,"
                + KEY_SUBMITTED_BY + " TEXT,"
                + KEY_DATE_CREATED + " TEXT,"
                + KEY_DATE_MODIFIED + " TEXT " + ")";
        db.execSQL(CREATE_CHILDREN_TABLE);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOTHERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHILDREN);


        // Create tables again
        onCreate(db);
    }


    /***********************************************************************************************************************
     *                      CLEAR TABLE DATA FUNCTION
     ***********************************************************************************************************************/
    public void clearTable(String table) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("DELETE FROM " + table);
    }

    /***********************************************************************************************************************
     *                      COPY TABLE DATA FUNCTION TO ANOTHER TABLE
     ***********************************************************************************************************************/
    public void copyTableData(String table1, String table2) {

        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("INSERT INTO " + table1 + " SELECT * FROM " + table2);

    }


    /***********************************************************************************************************************
     *                      INSERT FUNCTIONS
     ***********************************************************************************************************************/


//    public void insertMother(ArrayList<Mother> listUsers) {
//        SQLiteDatabase database = this.getWritableDatabase();
//
//        //create a SQL prepared statement
//        String sql = "INSERT OR REPLACE INTO " + TABLE_USERS + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);";
//
//        //compile the statement and start a transaction
//        SQLiteStatement statement = database.compileStatement(sql);
//        database.beginTransactionNonExclusive();
//
//        for (int i = 0; i < listUsers.size(); i++) {
//
//            Users currentUser = listUsers.get(i);
//
//            //statement.clearBindings();
//            //for a given column index, simply bind the data to be put inside that index
//            statement.bindLong(2, currentUser.getUser_id());
//            statement.bindString(3, currentUser.getUser_name());
//            statement.bindString(4, currentUser.getFull_name());
//            statement.bindString(5, currentUser.getPassword());
//            statement.bindString(6, currentUser.getEmail_address());
//            statement.bindLong(7, currentUser.getUser_type());
//            statement.bindLong(8, currentUser.getUser_level());
//            statement.bindString(9, currentUser.getAccess_level_description());
//            statement.bindLong(10, currentUser.getCompany_id());
//            statement.bindString(11, currentUser.getCompany_name());
//            statement.bindLong(12, currentUser.getBranch_id());
//            statement.bindString(13, currentUser.getBranch_name());
//
//            statement.execute();
//            statement.clearBindings();
//        }
//        //set the transaction as successful and end the transaction
//        Log.d("LOG_TAG", "inserting Users " + listUsers.size());// + new Date(System.currentTimeMillis()));
//        database.setTransactionSuccessful();
//        database.endTransaction();
//        database.close();
//    }
    public long insertMother(
            String othernames,
            String surname,
            String dob,
            String current_age,
            String nrc,
            String gender,
            String phone_number,
            String submitted_by,
            String date_created) {
        long row_inserted_id;
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        //for a given column index, simply bind the data to be put inside that index
        //values.putNull("");
        values.put(KEY_OTHERNAMES, othernames);//cashier_id
        values.put(KEY_SURNAME, surname);//cashier_name
        values.put(KEY_DOB, dob);// date of cashier
        values.put(KEY_CURRENT_AGE, current_age);// time of cashier login
        values.put(KEY_NRC, nrc);// time of cashier login
        values.put(KEY_GENDER, gender);// time of cashier login
        values.put(KEY_PHONE_NUMBER, phone_number);// time of cashier login
        values.put(KEY_SUBMITTED_BY, submitted_by);// time of cashier login
        values.put(KEY_DATE_CREATED, date_created);// time of cashier login
        values.put(KEY_DATE_MODIFIED, date_created);// time of cashier login

        row_inserted_id = database.insert(TABLE_MOTHERS, null, values);
        database.close();
        return row_inserted_id;
    }

    public long insertChild(
            String mother_id,
            String othernames,
            String surname,
            String dob,
            String current_age,
            String gender,
            String submitted_by,
            String date_created) {
        long row_inserted_id;
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        //for a given column index, simply bind the data to be put inside that index
        //values.putNull("");
        values.put(KEY_MOTHER_ID, mother_id);//cashier_id
        values.put(KEY_OTHERNAMES, othernames);//cashier_id
        values.put(KEY_SURNAME, surname);//cashier_name
        values.put(KEY_DOB, dob);// date of cashier
        values.put(KEY_CURRENT_AGE, current_age);// time of cashier login
        values.put(KEY_GENDER, gender);// time of cashier login
        values.put(KEY_SUBMITTED_BY, submitted_by);// time of cashier login
        values.put(KEY_DATE_CREATED, date_created);// time of cashier login
        values.put(KEY_DATE_MODIFIED, date_created);// time of cashier login

        row_inserted_id = database.insert(TABLE_CHILDREN, null, values);
        database.close();
        return row_inserted_id;
    }

    /***********************************************************************************************************************
     *                      GET FUNCTIONS
     ***********************************************************************************************************************/
    public ArrayList<Mother> getMothersBasedOnUserLoggedIn(String user_id) {
        SQLiteDatabase database = this.getReadableDatabase();

        ArrayList<Mother> listMother = new ArrayList<>();

        String Query = "SELECT * FROM  '" + TABLE_MOTHERS + "'  WHERE   " + KEY_LID + "='" + user_id + "'  ";
        Mother mother = null;
        Cursor cursor = database.rawQuery(Query, null);
        if (cursor != null && cursor.moveToFirst()) {

            do {
                //create a new customer object and retrieve the data from the cursor to be stored in this customer object
                Mother currentMother = new Mother();

                //each step is a 2 part process, find the index of the column first, find the data of that column using


                currentMother.setMother_id(cursor.getInt(cursor.getColumnIndex(KEY_LID)));
                currentMother.setOthernames(cursor.getString(cursor.getColumnIndex(KEY_OTHERNAMES)));
                currentMother.setSurname(cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
                currentMother.setDob(cursor.getString(cursor.getColumnIndex(KEY_DOB)));
                currentMother.setNrc(cursor.getString(cursor.getColumnIndex(KEY_NRC)));
                currentMother.setGender(cursor.getString(cursor.getColumnIndex(KEY_GENDER)));
                currentMother.setPhone_number(cursor.getString(cursor.getColumnIndex(KEY_PHONE_NUMBER)));
                currentMother.setDate_created(cursor.getString(cursor.getColumnIndex(KEY_DATE_CREATED)));


                //add the customer to the list of customer objects which we plan to return
                listMother.add(currentMother);
            } while (cursor.moveToNext());

        }
        return listMother;

    }

    public ArrayList<Children> getChildrenBasedOnMother(String mother_id) {
        SQLiteDatabase database = this.getReadableDatabase();

        ArrayList<Children> listChildren = new ArrayList<>();

        String Query = "SELECT * FROM  '" + TABLE_CHILDREN + "'  WHERE   " + KEY_MOTHER_ID + "='" + mother_id + "'  ";
//        String Query = "SELECT * FROM  tbl_children" ;
        Children children = null;
        Cursor cursor = database.rawQuery(Query, null);
        if (cursor != null && cursor.moveToFirst()) {

            do {
                //create a new customer object and retrieve the data from the cursor to be stored in this customer object
                Children currentChildren = new Children();

                //each step is a 2 part process, find the index of the column first, find the data of that column using


                currentChildren.setMother_id(cursor.getInt(cursor.getColumnIndex(KEY_LID)));
                currentChildren.setOthernames(cursor.getString(cursor.getColumnIndex(KEY_OTHERNAMES)));
                currentChildren.setSurname(cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
                currentChildren.setDob(cursor.getString(cursor.getColumnIndex(KEY_DOB)));
                currentChildren.setGender(cursor.getString(cursor.getColumnIndex(KEY_GENDER)));
                currentChildren.setDate_created(cursor.getString(cursor.getColumnIndex(KEY_DATE_CREATED)));


                //add the customer to the list of customer objects which we plan to return
                listChildren.add(currentChildren);
            } while (cursor.moveToNext());

        }
        return listChildren;

    }


}
