package com.haroldking.nutritionapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.haroldking.nutritionapp.adapters.MothersAdapter;
import com.haroldking.nutritionapp.databases.DatabaseHelper;
import com.haroldking.nutritionapp.model.Mother;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MothersActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    Context context;
    TextView save_mother;
    EditText othernames, surname, nrc, phone_number;
    TextView no_mothers_txt;

    RecyclerView mothers_recylerview;
    MothersAdapter mothersAdapter;
    ArrayList<Mother> listMothers = new ArrayList<>();
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss", Locale.ENGLISH);
Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mothers);
        toolbar = findViewById(R.id.toolbar);
        no_mothers_txt = findViewById(R.id.no_mothers_txt);

        mothers_recylerview = findViewById(R.id.mothers_recylerview);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Mothers");
        toolbar.setSubtitle("List Of Mothers Being Cared For");
//        toolbar.setNavigationIcon(android.R.drawable.abc_ic_ab_back_material);
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//                startActivity(intent);
//            }
//        });

//        save_mother = findViewById(R.id.save_mother);

        context = MothersActivity.this;
        databaseHelper = new DatabaseHelper(context);
        listMothers = databaseHelper.getMothersBasedOnUserLoggedIn("1");
        if (listMothers.size() <= 0) {
            mothers_recylerview.setVisibility(View.GONE);
            no_mothers_txt.setVisibility(View.VISIBLE);
        } else {
            mothers_recylerview.setHasFixedSize(true);
            mothers_recylerview.setLayoutManager(new LinearLayoutManager(getBaseContext()));
            mothers_recylerview.addItemDecoration(new DividerItemDecoration(getBaseContext(), DividerItemDecoration.HORIZONTAL));
            mothersAdapter = new MothersAdapter(getBaseContext(), listMothers);
            mothers_recylerview.setAdapter(mothersAdapter);
            mothersAdapter.setClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = mothers_recylerview.getChildLayoutPosition(view);
                    Mother mother = listMothers.get(position);
                    Toast.makeText(getApplicationContext(), "Mother_id: " +  mother.getMother_id(), Toast.LENGTH_SHORT).show();
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("mother_id", String.valueOf(mother.getMother_id()));
                    editor.apply();
                    finish();
                    Intent intent = new Intent(getApplicationContext(), MotherDetailsActivity.class);
                    intent.putExtra("mother_id", mother.getMother_id() );
                    intent.putExtra("othernames", mother.getOthernames() );
                    intent.putExtra("surname", mother.getSurname());
                    intent.putExtra("nrc", mother.getNrc());
                    intent.putExtra("dob", mother.getDob());
                    intent.putExtra("phone_number", mother.getPhone_number());
                    startActivity(intent);

                }
            });
        }

//        save_mother.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String st_othernames = othernames.getText().toString();
//                String st_surname = surname.getText().toString();
//                String st_dob = dob.getText().toString();
//                String st_current_age = "10";//current_age.getText().toString();
//                String st_nrc = nrc.getText().toString();
//                String st_phone_number = phone_number.getText().toString();
//                String st_date_created = date_created();
//                long rowInserted = databaseHelper.insertMother(
//                        st_othernames,
//                        st_surname,
//                        st_dob,
//                        st_current_age,
//                        st_nrc,
//                        "F",
//                        0,
//                        st_phone_number,
//                        st_date_created);
//                if (rowInserted != -1)
//                    Toast.makeText(getApplicationContext(), "Successfully Saved " + othernames + " " + surname, Toast.LENGTH_SHORT).show();
//                else
//                    Toast.makeText(getApplicationContext(), "Failed to Save " + othernames + " " + surname, Toast.LENGTH_SHORT).show();
//
//            }
//        });
    }

    private String date_created() {
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        DateFormat dateFormat = sdf;
        //System.out.println("Current time of the day using Calendar - 24 hour format: "+ formattedDate);
        return dateFormat.format(date);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_add_item) {
            finish();
            Intent intent = new Intent(getApplicationContext(), AddMothersActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        finish();
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}