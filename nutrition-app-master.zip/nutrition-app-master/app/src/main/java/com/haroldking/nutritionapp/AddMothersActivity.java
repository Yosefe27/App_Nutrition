package com.haroldking.nutritionapp;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.haroldking.nutritionapp.databases.DatabaseHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddMothersActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    Context context;
    TextView save_mother;
    EditText othernames, surname, nrc, phone_number;
    TextView dob;
    DatePickerDialog picker;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss", Locale.ENGLISH);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_mothers);

        othernames = findViewById(R.id.othernames);
        surname = findViewById(R.id.surname);
        dob = findViewById(R.id.dob);
//        current_age = findViewById(R.id.current_age);
        nrc = findViewById(R.id.nrc);
        phone_number = findViewById(R.id.phone_number);
        save_mother = findViewById(R.id.save_mother);

        context = AddMothersActivity.this;
        databaseHelper = new DatabaseHelper(context);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setDateOfBirth(dob);
            }
        });
        save_mother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String st_othernames = othernames.getText().toString();
                String st_surname = surname.getText().toString();
                String st_dob = dob.getText().toString();
                String st_current_age = "10";//current_age.getText().toString();
                String st_nrc = nrc.getText().toString();
                String st_phone_number = phone_number.getText().toString();
                String st_date_created = date_created();
                long rowInserted = databaseHelper.insertMother(
                        st_othernames,
                        st_surname,
                        st_dob,
                        st_current_age,
                        st_nrc,
                        "F",
                        st_phone_number,
                        "1",
                        st_date_created);
                if (rowInserted != -1) {
                    Toast.makeText(getApplicationContext(), "Successfully Saved " + st_othernames + " " + st_surname, Toast.LENGTH_SHORT).show();
                    finish();
                    Intent intent = new Intent(getApplicationContext(), MothersActivity.class);
                    startActivity(intent);
                } else
                    Toast.makeText(getApplicationContext(), "Failed to Save " + st_othernames + " " + st_surname, Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void setDateOfBirth(final TextView textView) {
        final Calendar cldr = Calendar.getInstance();
        int day = cldr.get(Calendar.DAY_OF_MONTH);
        int month = cldr.get(Calendar.MONTH);
        int year = cldr.get(Calendar.YEAR);
        // date picker dialog
        picker = new DatePickerDialog(context,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
//                         textView.setText(String.valueOf(dayOfMonth + "/" + monthOfYear + "/" + year));
                        textView.setText(year + "-" + monthOfYear + "1-" + dayOfMonth);
                        // textView.setTypeface(Typeface.DEFAULT_BOLD);
                        textView.setTextColor(getResources().getColor(R.color.colorPrimary));
                    }

//                @Override
//                public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
//
//                }
                }, year, month, day);
        picker.show();
    }

    private String date_created() {
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        DateFormat dateFormat = sdf;
        //System.out.println("Current time of the day using Calendar - 24 hour format: "+ formattedDate);
        return dateFormat.format(date);
    }
}