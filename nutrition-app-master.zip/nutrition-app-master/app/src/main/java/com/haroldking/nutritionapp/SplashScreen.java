package com.haroldking.nutritionapp;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.haroldking.nutritionapp.databases.DatabaseHelper;
import com.haroldking.nutritionapp.model.Towns;

import java.util.ArrayList;


/**
 * Created by Harold King on 17/01/2020.
 */

public class SplashScreen extends AppCompatActivity {

    Context context;
    private ArrayList<Towns> listTowns = new ArrayList<>();

    DatabaseHelper databaseHelper;


    private static int SPLASH_TIME_OUT = 2500;

    //String intentNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
//        btn_loader_1 = findViewById(R.id.btn_loader_1);
//        btn_loader_2 = findViewById(R.id.btn_loader_2);
//        btn_loader_3 = findViewById(R.id.btn_loader_3);
//        btn_loader_4 = findViewById(R.id.btn_loader_4);
//        btn_loader_5 = findViewById(R.id.btn_loader_5);


        databaseHelper = new DatabaseHelper(this);
        Bitmap icon = BitmapFactory.decodeResource(getResources(), android.R.drawable.btn_star);
        new Handler().postDelayed(new Runnable() {
            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */
            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity

//[do some async task. When it finishes]
//You can choose the color and the image after the loading is finished
//                btn.doneLoadingAnimation(R.color.colorAccent, icon);
                finish();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        }, SPLASH_TIME_OUT);


    }


    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }


    public static int getVersionCode(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
            return pi.versionCode;
        } catch (PackageManager.NameNotFoundException ex) {
        }
        return 0;
    }


}
